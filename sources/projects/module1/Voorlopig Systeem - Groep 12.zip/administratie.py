from tkinter import *
import sqlite3
import tkinter
import tkinter.messagebox
import filldb

class App(tkinter.Tk):
    def __init__(self, parent):
        tkinter.Tk.__init__(self, parent)
        self.parent = parent
        self.frame = Frame()
        self.frame.destroy()

        self.initialize_administratie_gebruiker()

    # Create GUI in this function
    # No logic yet
    def initialize_administratie_gebruiker(self):
        print(type(self.frame))
        self.clear_grid()
        self.frame = Frame(
            relief = SUNKEN,
            bd = 5
        )

        self.frame.grid()
        print(type(self.frame))

        # ============ Header ================
        self.frame.label_administratie_gebruiker = tkinter.Label(
            self.frame,
            text="Administratie gebruiker",
            font=("Helvetica", 25)
        )
        self.frame.label_administratie_gebruiker.grid(
            column=0,
            row=0,
            sticky="W",
            columnspan=4
        )

        self.button_gebruiker_toevoegen = tkinter.Button(
            self.frame,
            text="Gebruiker toevoegen",
            command = self.initialize_add_user
        )
        self.button_gebruiker_toevoegen.grid(
            column=6,
            row=0,
            sticky="EW"
        )

        # List database data
        sql_get_all_users = """ SELECT * FROM user """
        self.c.execute(sql_get_all_users)


        # Get all data in a nice grid
        i = 0
        data = self.c.fetchall()
        for row in data:
            k = 0
            for column in row:
                self.column = Label(
                    self.frame,
                    text=column,
                )
                self.column.grid(
                    column=k,
                    row=i + 2,
                    sticky='W'
                )
                k = k + 1
            self.column = Button(
                self.frame,
                text="Delete user",
                command=lambda t=row[0]: self.deleteuser(t)
            )
            self.column.grid(
                column=k + 1,
                row=i + 2,
                sticky="W"
            )

            i = i + 1

    def initialize_add_user(self):
        self.clear_grid()
        self.frame = Frame()
        self.frame.grid()

        # ============ Header ================
        self.frame.label_administratie_gebruiker = tkinter.Label(
            self.frame,
            text="Toevoegen gebruiker",
            font=("Helvetica", 25)
        )
        self.frame.label_administratie_gebruiker.grid(
            column=0,
            row=0,
            sticky="W",
            columnspan=4
        )

        self.button_administratie_gebruikers = tkinter.Button(
            self.frame,
            text="Overzicht gebruikers",
            command = self.initialize_administratie_gebruiker
        )
        self.button_administratie_gebruikers.grid(
            column=6,
            row=0,
            sticky="EW"
        )

        # Entries for name etc.

        self.label_name = Label(
            self.frame,
            text="Voornaam:"
        )
        self.label_name.grid(
            column = 0,
            row = 3,
            sticky="W"
        )

        self.name = Entry(
            self.frame,
            text="Voornaam"
        )
        self.name.grid(
            column = 1,
            row = 3,
            sticky="W"
        )

        self.label_surname = Label(
            self.frame,
            text="Achternaam:"
        )
        self.label_surname.grid(
            column = 0,
            row = 4,
            sticky="W"
        )

        self.surname = Entry(
            self.frame,
            text="Achternaam"
        )
        self.surname.grid(
            column = 1,
            row =4,
            sticky="W"
        )

        self.label_card = Label(
            self.frame,
            text="Pasje:"
        )
        self.label_card.grid(
            column = 0,
            row = 5,
            sticky="W"
        )

        self.card = Entry(
            self.frame,
            text="Pasje"
        )
        self.card.grid(
            column = 1,
            row = 5,
            sticky="W"
        )

        self.label_subscription = Label(
            self.frame,
            text="Abonnement:"
        )
        self.label_subscription.grid(
            column=0,
            row=6,
            sticky="W"
        )

        # Get data from db for subscriptiondropdown
        sql = """ SELECT name FROM subscription """
        self.c.execute(sql)
        self.conn.commit()
        data = self.c.fetchall()
        print(data)
        self.subscription_option= StringVar(self.frame)
        self.subscription_option.set("Selecteer uw abonnement")


        self.subscription = OptionMenu((self.frame, self.subscription_option) + tuple(data))

        self.subscription.grid(
            column=1,
            row=6
        )

        self.add_user = Button(
            self.frame,
            text="Voeg gebruiker toe",
            command=self.get_entries
        )
        self.add_user.grid(
            column=1,
            row=7,
            sticky="W"
        )

    def get_entries(self):
        self.name_entry = self.name.get()
        self.surname_entry = self.surname.get()
        self.card_entry = self.card.get()
        self.subscription_entry = self.subscription_option.get()
        filldb.adduser("jo","anne","Premium",1234567890098765432)
        self.conn.commit()

    def deleteuser(self, iduser):
        if (self.confirm_delete_user() == True):
            print(iduser)
            self.c.execute("DELETE FROM user WHERE iduser = ?", (iduser,))
            self.c.execute("DELETE FROM usersubscription WHERE iduser = ?", (iduser,))
            self.conn.commit()
            self.clear_grid()
            self.initialize_administratie_gebruiker()

    def confirm_delete_user(self):
        var = tkinter.messageBox.askokcancel(
            title="Delete gebruiker",
            message="Wilt u de gebruiker echt verwijderen?"
        )
        return var

    def clear_grid(self):
        if self.frame.winfo_exists() == 1:
            self.frame.destroy()


# Run the application
if __name__ == "__main__":
    app = App(None)
    app.title('Administration')
    app.mainloop()
