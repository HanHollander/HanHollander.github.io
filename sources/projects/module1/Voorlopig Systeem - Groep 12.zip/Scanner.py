import ArduinoConnection

running = True


def scanner(screen_a):
    global filldb
    filldb = __import__("filldb")
    # ------------------------------------------------------------------------
    # ArduinoConnection.connect()
    # ------------------------------------------------------------------------
    screen_a.updateStatus("Database ready")
    id = -1
    cframe = None
    while running:
        oldid = id
        oldframe = cframe
        id = ArduinoConnection.catch()
        cframe = screen_a.frame.__class__.__name__
        if id != oldid or oldframe != cframe:
            status = filldb.authorize(id)
            if screen_a.frame.__class__.__name__ == "ScanFrame":
                checkIfAllowed(status, screen_a)
            elif screen_a.frame.__class__.__name__ == "AdminFrame":
                updateAdminField(id, screen_a)
            else:
                print(-1)


def checkIfAllowed(status, screen_a):
    screen_a.getFrame().updateScreen(status)

def updateAdminField(id, screen_a):
    screen_a.getFrame().getLabel(1).config(text=str(id))
