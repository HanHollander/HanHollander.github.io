import serial


def connect():
    global ser
    ser = serial.Serial('COM5', 9600)


def catch():
    return int(ser.readline()[:-1].decode('ascii'), 10)