__author__ = 'Jeroen'

from tkinter import *


class Window:
    def __init__(self, master, w, h):
        self.master = master
        self.w = w
        self.h = h
        self.status = "Creating database..."
        self.frame = ScanFrame(self, master, w, h, self.status)

    def setAdminFrame(self):
        self.frame.pack_forget()
        self.frame.destroy()
        self.frame = AdminFrame(self, self.master, self.w, self.h, self.status)

    def setScanFrame(self):
        self.frame.pack_forget()
        self.frame.destroy()
        self.frame = ScanFrame(self, self.master, self.w, self.h, self.status)

    def getMaster(self):
        return self.master

    def getFrame(self):
        return self.frame

    def updateStatus(self, string):
        self.status = string
        self.frame.getLabel(0).config(text=string)

class myFrame(Frame):
    def __init__(self, window, master, w, h, status):
        Frame.__init__(self, master)

        self.master = master
        self.window = window
        self.w = w
        self.h = h

        self.pack(fill=BOTH, expand=1)

        quitButton = Button(self, text="Afsluiten", command=self.quit)
        quitButton.place(x=25, y=25)

        toggleButton = Button(self)
        toggleButton.place(x=100, y=25)
        self.toggleButton = toggleButton

        label0 = Label(self, text=status)
        label0.place(x=self.w - label0.winfo_reqwidth() - 20, y=25)
        self.label0 = label0

        label1 = Label(self)
        self.label1 = label1

    def getLabel(self, i):
        if i == 0:
            return self.label0
        elif i == 1:
            return self.label1

class ScanFrame(myFrame):
    def __init__(self, window, master, w, h, status):
        myFrame.__init__(self, window, master, w, h, status)

        self.toggleButton.config(text="Administratie", command=window.setAdminFrame)

        self.scanUwPas = PhotoImage(file="scanUwPas.png")
        self.allow = PhotoImage(file="allow.png")
        self.denied = PhotoImage(file="denied.png")
        self.label1.config(image=self.scanUwPas)
        self.label1.photo = self.scanUwPas
        self.label1.place(y=(self.h - 228)//2, x=(self.w - 942)//2)

    def updateScreen(self, status):
        if status:
            self.label1.config(image=self.allow)
            self.label1.photo = self.allow
        else:
            self.label1.config(image=self.denied)
            self.label1.photo = self.denied


class AdminFrame(myFrame):
    def __init__(self, window, master, w, h, status):
        myFrame.__init__(self, window, master, w, h, status)

        self.toggleButton.config(text="Scanner", command=window.setScanFrame)



def setup():
    root = Tk()
    root.configure(background='white')
    root.overrideredirect(True)
    screenWidth = root.winfo_screenwidth()
    screenHeight = root.winfo_screenheight()

    root.geometry("{0}x{1}+0+0".format(screenWidth, screenHeight))
    screen = Window(root, screenWidth, screenHeight)
    return screen
