import GUI
import _thread
import Scanner

print("MainController: creating screen...")
screen = GUI.setup()
root = screen.getMaster()
print("MainController: screen created")

print("MainController: start scanner thread")
_thread.start_new_thread(Scanner.scanner, (screen,))

root.mainloop()
Scanner.running = False