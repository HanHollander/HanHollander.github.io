import ArduinoConnection

running = True


def scanner(screen_a):
    global filldb
    filldb = __import__("filldb")

    screen_a.updateStatus("Database ready")
    while running:
        id = ArduinoConnection.catch()
        status = filldb.authorize(id)
        # checkin or checkout
        if status:
            ArduinoConnection.send()
            if filldb.checkedin(id):
                filldb.checkout(id)
                status = 3
                screen_a.getFrame().updateS(id, status)
            else:
                filldb.checkin(id)
                status = 4
                screen_a.getFrame().updateS(id, status)
        else:
            status = 1
            screen_a.getFrame().updateS(id, status)