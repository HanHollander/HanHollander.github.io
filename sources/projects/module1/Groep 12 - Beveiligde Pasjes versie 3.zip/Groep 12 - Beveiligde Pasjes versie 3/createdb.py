import sqlite3


def createdb():
    # connect to pasjes.db, if pasjes.db doesn't exist create it
    conn = sqlite3.connect("testdatabase.db")
    c = conn.cursor()
    # USER
    c.execute("DROP TABLE IF EXISTS user")
    c.execute("CREATE TABLE IF NOT EXISTS user"
              "(iduser INT NOT NULL, "
              "name TEXT NOT NULL, "
              "surname TEXT NOT NULL, "
              "idtag INT NOT NULL, "
              "PRIMARY KEY (iduser))")
    print("createdb: user table created")
    # SUBSCRIPTION
    c.execute("DROP TABLE IF EXISTS subscription")
    c.execute("CREATE TABLE IF NOT EXISTS subscription"
              "(idsubscription INT NOT NULL, "
              "name VARCHAR(45) NOT NULL, "
              "price DECIMAL(10) NOT NULL,"
              "duration INT NOT NULL, "
              "PRIMARY KEY (idsubscription)) ")
    print("createdb: subscription table created")
    # CHECKIN
    c.execute("DROP TABLE IF EXISTS checkin")
    c.execute("CREATE TABLE IF NOT EXISTS checkin "
              "(idcheckin INT NOT NULL, "
              "iduser INT NOT NULL, "
              "time TIME NOT NULL, "
              "PRIMARY KEY (idcheckin, iduser))")
    print("createdb: checkin table created")
    # CHECKOUT
    c.execute("DROP TABLE IF EXISTS checkout")
    c.execute("CREATE TABLE IF NOT EXISTS checkout "
              "(idcheckout INT NOT NULL, "
              "iduser INT NOT NULL, "
              "time TIME NOT NULL, "
              "PRIMARY KEY (idcheckout, iduser))")
    print("createdb: checkout table created")
    # ADMIN
    c.execute("DROP TABLE IF EXISTS admin")
    c.execute("CREATE TABLE IF NOT EXISTS admin "
              "(idadmin INT NOT NULL, "
              "name TEXT NOT NULL, "
              "surname TEXT NOT NULL, "
              "password VARCHAR(45) NOT NULL, "
              "PRIMARY KEY (idadmin))")
    print("createdb: admin table created")
    # USERSUBSCRIPTION
    c.execute("DROP TABLE IF EXISTS usersubscription")
    c.execute("CREATE TABLE IF NOT EXISTS usersubscription "
              "(iduser INT NOT NULL, "
              "idsubscription INT NOT NULL, "
              "purchased DATE NOT NULL, "
              "validuntil DATE NOT NULL, "
              "PRIMARY KEY (iduser, idsubscription))")
    print("createdb: usersubscription table created")
    # commit the changes
    conn.commit()
