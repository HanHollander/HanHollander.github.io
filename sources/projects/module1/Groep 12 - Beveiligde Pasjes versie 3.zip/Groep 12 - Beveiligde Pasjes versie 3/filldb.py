import sqlite3
import time
import datetime
import hashlib
from createdb import createdb
import random

# -------------#
#### setup ####
# -------------#

print("filldb: connecting to database...")
# connect to pasjes.db
conn = sqlite3.connect("testdatabase.db")
c = conn.cursor()
print("filldb: database connected")

# ---------------------------#
#### auxiliary functions ####
# ---------------------------#

def getmax(id, table):
    # create a query
    query = "SELECT max(" + id + ") FROM " + table
    # execute a query
    c.execute(query)
    maxid = c.fetchone()[0]
    # determine count
    if maxid is None:
        count = 1
    else:
        count = maxid + 1
    return count


# ------------------------------------#
#### functions to add to database ####
# ------------------------------------#

# function to add admin
def addadmin(name, surname, password):
    # add admin to database with unique idadmin
    count = getmax("idadmin", "admin")
    # hash the password
    password = hashlib.sha256(repr(password).encode('utf-8')).hexdigest()
    admin = (count, name, surname, password)
    c.execute("INSERT INTO admin VALUES (?,?,?,?)", admin)
    conn.commit()


# function to add subcription type
def addsubscription(name, price, duration):
    # add subscription to database with unique idsubscription
    count = getmax("idsubscription", "subscription")
    subscription = (count, name, price, duration)
    c.execute("INSERT INTO subscription VALUES (?,?,?,?)", subscription)
    conn.commit()


# function to add users
def adduser(name, surname, subscription, idtag):
    # select what the duration of the subscription is
    c.execute("SELECT duration FROM subscription WHERE name = ?", (subscription,))
    duration = c.fetchone()
    # select the max id in user
    count = getmax("iduser", "user")
    # date of entry
    currentdate = datetime.datetime.strptime(time.strftime("%d/%m/%y"), "%d/%m/%y")
    # add user to database with unique iduser and rsa-encrypted idtag
    user = (count, name, surname, idtag)  # surname,hashlib.sha256(repr(idtag).encode('utf-8')).hexdigest())
    c.execute("INSERT INTO user VALUES (?,?,?,?)", user)
    # add subscription to relation usersubscription
    c.execute("INSERT INTO usersubscription VALUES ("
              "?, "
              "(SELECT idsubscription FROM subscription WHERE name = ?), "
              "?, ?)", (count, subscription, currentdate, currentdate + datetime.timedelta(weeks=duration[0])))
    conn.commit()


# -------------------------------#
#### function to record time ####
# -------------------------------#

# function to record checkin time
def checkin(idtag):
    # select id of user
    c.execute("SELECT iduser FROM user WHERE idtag = ?", (idtag,))
    iduser = c.fetchone()
    # get unique id
    if iduser is not None:
        count = getmax("idcheckin", "checkin")
        # get time
        time = datetime.datetime.now()
        # add to checkin
        c.execute("INSERT INTO checkin VALUES (?, ?, ?)", (count, iduser[0], time))
    conn.commit()


# function to record checkout time
def checkout(idtag):
    # select the id of user
    c.execute("SELECT iduser FROM user WHERE idtag = ?", (idtag,))
    iduser = c.fetchone()
    # get unique id
    if iduser is not None:
        count = getmax("idcheckout", "checkout")
        # get time
        time = datetime.datetime.now()
        # add to checkout
        c.execute("INSERT INTO checkout VALUES (?, ?, ?)", (count, iduser[0], time))
    conn.commit()

# function to check if checked id
def checkedin(idtag):
    # select id of user
    c.execute("SELECT iduser FROM user WHERE idtag = ?", (idtag,))
    iduser = c.fetchone()
    if iduser is not None:
        c.execute("SELECT count(*) FROM checkin WHERE iduser = ?", (iduser[0],))
        checkins = c.fetchone()
        c.execute("SELECT count(*) FROM checkout WHERE iduser = ?", (iduser[0],))
        checkouts = c.fetchone()
        if (checkins[0] + checkouts[0]) % 2 == 0:
            return False
        else:
            return True

# -----------------------------------------#
#### functions to delete from database ####
# -----------------------------------------#

# function do delete users
def deleteuser(iduser):
    # delete user from user
    c.execute("DELETE FROM user WHERE iduser = ?", (iduser,))
    # delete user from usersubscription
    c.execute("DELETE FROM usersubscription WHERE iduser = ?", (iduser,))
    conn.commit()


# ---------------------------------------#
#### function to check authorization ####
# ---------------------------------------#

def authorize(idtag):
    # select id of user
    c.execute("SELECT iduser FROM user WHERE idtag = ?", (idtag,))
    iduser = c.fetchone()
    if iduser is not None:
        # get time
        time = datetime.datetime.now()
        # get validuntil
        c.execute("SELECT validuntil FROM usersubscription WHERE iduser = ?", iduser)
        validuntil = c.fetchone()
        conn.commit()
        # return if authorized
        validuntil = datetime.datetime.strptime(validuntil[0], "%Y-%m-%d %H:%M:%S")
        return time < validuntil
    else:
        return False

# ----------------------------------#
#### functions to update values ####
# ----------------------------------#

# function to change a value with one condition
def update(table, column, newval, condition, conditionval):
    # new value and condition
    updateval = (newval, conditionval,)
    # create a string which will be the query
    query = "UPDATE " + table + " SET " + column + " = ? WHERE " + condition + " = ?"
    # execute the string query
    c.execute(query, updateval)
    conn.commit()


# -------------------------#
#### fill the database ####
# ---#### OPTIONAL ####----#
# -------------------------#
# print("filldb: Start filling database...")
#
# addsubscription("Standaard", 20, 4)
# addsubscription("Premium", 420, 20)
#
# i = 1
# while i <= 100:
#
#     rand = random.randint(0, 100)
#     if rand > 20:
#         subscription = "Standaard"
#     else:
#         subscription = "Premium"
#     adduser("User", "Test", subscription, i)
#     i += 1
#
# addadmin("Admin", "Test", "Password")
#
# print("filldb: Database was filled...")