import serial
import glob
import serial.tools.list_ports
ports = list(serial.tools.list_ports.comports())
for p in ports:
    if "Arduino" in p[1]:
        comport = p[0]

ser = serial.Serial(comport, 9600)


def catch():
    return ser.readline()[:-1].decode('ascii')

def send():
    ser.write(b'1')