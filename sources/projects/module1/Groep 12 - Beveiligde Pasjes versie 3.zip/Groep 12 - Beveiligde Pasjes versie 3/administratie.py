from tkinter import *
import tkinter.messagebox
import sqlite3
import tkinter
import filldb
import hashlib
import ArduinoConnection

class App(tkinter.Tk):
    def __init__(self, parent):
        tkinter.Tk.__init__(self, parent)
        self.parent = parent
        self.frame = Frame()
        self.headerFrame = Frame()
        self.mainFrame = Frame()
        self.logged_in = False

        self.quitButton = Button(self, text="Afsluiten", command=self.quit)
        self.quitButton.place(x=(self.winfo_screenwidth() - self.quitButton.winfo_reqwidth()) - 10, y=10)

        # Database conn
        self.conn = sqlite3.connect("testdatabase.db")
        self.c = self.conn.cursor()

        self.initialize_login()

    def initialize_login(self):
        self.clear_grid()

        if (self.logged_in == True):
            self.initialize_administratie_gebruiker()
        else:
            # Create form

            self.frame = Frame(
                bd=5,
                relief=SUNKEN,
            )
            self.frame.pack()

            self.frame.label_login = tkinter.Label(
                self.frame,
                text="Login",
                font=("Helvetica", 23)
            )
            self.frame.label_login.grid(
                column=0,
                row=0,
                sticky="W",
                columnspan=4
            )

            self.username_label = Label(
                self.frame,
                text="Voornaam"
            )
            self.username_label.grid(
                column=0,
                row=3,
                sticky="W"
            )

            self.name = Entry(
                self.frame
            )
            self.name.grid(
                column=1,
                row=3,
                sticky="W"
            )

            self.surname_label = Label(
                self.frame,
                text="Achternaam"
            )
            self.surname_label.grid(
                column=0,
                row=4,
                sticky="W"
            )

            self.surname = Entry(
                self.frame
            )
            self.surname.grid(
                column=1,
                row=4,
                sticky="W"
            )

            self.password_label = Label(
                self.frame,
                text="Wachtwoord"
            )
            self.password_label.grid(
                column=0,
                row=5,
                sticky="W"
            )

            self.password = Entry(
                self.frame,
                show="*"
            )
            self.password.grid(
                column=1,
                row=5,
                sticky="W"
            )

            self.submit_button = Button(
                self.frame,
                text="Login",
                command=self.login_execute
            )
            self.submit_button.grid(
                column=1,
                row=6,
                sticky="E"
            )

            self.frame.update()
            self.frame.place(x=(self.winfo_screenwidth() - self.frame.winfo_width())//2, y=0)

    def login_execute(self):
        sql_query = "SELECT * FROM admin WHERE name = ? AND surname = ? AND password = ?"
        self.c.execute(sql_query, (
            self.name.get(),
            self.surname.get(),
            hashlib.sha256(repr(self.password.get()).encode('utf-8')).hexdigest()
        ))
        self.conn.commit()
        if self.c.fetchall() != []:
            self.logged_in = True
            self.initialize_administratie_gebruiker()

    def initialize_administratie_gebruiker(self, page = 0):
        self.page = page
        self.clear_grid()
        self.frame = Frame(padx = 30, pady = 70,
            relief=SUNKEN,
            bd=5
        )

        self.frame.grid()

        # ============ Header ================
        self.frame.label_administratie_gebruiker = tkinter.Label(
            self.frame,
            text="Administratie gebruiker",
            font=("Helvetica", 25)
        )
        self.frame.label_administratie_gebruiker.grid(
            column=0,
            row=0,
            sticky="W",
            columnspan=4
        )

        self.button_gebruiker_toevoegen = tkinter.Button(
            self.frame,
            text="Gebruiker toevoegen",
            command=self.initialize_add_user
        )
        self.button_gebruiker_toevoegen.grid(
            column=6,
            row=0,
            sticky="EW"
        )

        self.button_abonnement_toevoegen = tkinter.Button(
            self.frame,
            text="Abonnement toevoegen",
            command=self.initialize_add_subscription
        )
        self.button_abonnement_toevoegen.grid(
            column=7,
            row=0,
            sticky="EW"
        )

        # Verder en terugbuttons
        if self.page > 0:
            self.button_terug = Button(self.frame, text="Terug", command = lambda : self.initialize_administratie_gebruiker(self.page-1))
            self.button_terug.grid(row = 1, column = 0)
        self.button_verder = Button(self.frame, text="Verder", command = lambda : self.initialize_administratie_gebruiker(self.page+1))
        self.button_verder.grid(row = 1, column = 1)



        self.frame.update()
        self.frame.place(x=(self.winfo_screenwidth() - self.frame.winfo_width())//2, y=0)

        # List database data
        sql_get_all_users =  """SELECT user.iduser, user.name, user.surname, subscription.name, user.idtag
            FROM user,usersubscription,subscription
            WHERE user.iduser = usersubscription.iduser
            AND usersubscription.idsubscription = subscription.idsubscription
            AND user.rowid Between """ + str(((self.page)*10 + 1)) + """ and """ + str(((self.page+1)*10)) + """ """
        self.c.execute(sql_get_all_users)


        # Get all data in a nice grid
        i = 0
        data = self.c.fetchall()

        # Get all data in a nice grid
        self.label_iduser = Label(self.frame, text="ID:")
        self.label_iduser.grid(column = 0, row = 2,sticky="W")
        self.label_name = Label(self.frame, text="Naam:")
        self.label_name.grid(column = 1, row = 2,sticky="W")
        self.label_surname = Label(self.frame, text="Achternaam:").grid(column = 2, row = 2, sticky="W")
        self.label_subscription = Label(self.frame,text="Abonnement:").grid(column = 3, row = 2, sticky = "W")
        self.label_card = Label(self.frame, text="Pasje ID:")
        self.label_card.grid(column = 4, row = 2,sticky="W")

        i = 0
        # data = self.c.fetchall()
        for row in data:
            k = 0
            for column in row:
                self.column = Label(
                    self.frame,
                    text=column,
                )
                self.column.grid(
                    column=k,
                    row=i + 4,
                    sticky='W'
                )
                k = k + 1
            self.column = Button(
                self.frame,
                text="Edit user",
                command=lambda t=row[0]: self.initialize_update_user(t)
            )
            self.column.grid(
                column=k + 1,
                row=i + 4,
                sticky="W"
            )
            self.column = Button(
                self.frame,
                text="Delete user",
                command=lambda t=row[0]: self.deleteuser(t)
            )
            self.column.grid(
                column=k + 2,
                row=i + 4,
                sticky="W"
            )

            i = i + 1

    def scanPas(self):
        id = ArduinoConnection.catch()
        ArduinoConnection.send()
        self.card.config(text=str(id))

    def initialize_add_user(self):
        self.clear_grid()

        self.frame = Frame()
        self.frame.grid()

        # ============ Header ================
        self.frame.label_administratie_gebruiker = tkinter.Label(
            self.frame,
            text="Toevoegen gebruiker",
            font=("Helvetica", 25)
        )
        self.frame.label_administratie_gebruiker.grid(
            column=0,
            row=0,
            sticky="W",
            columnspan=4
        )

        self.button_administratie_gebruikers = tkinter.Button(
            self.frame,
            text="Overzicht gebruikers",
            command=self.initialize_administratie_gebruiker
        )
        self.button_administratie_gebruikers.grid(
            column=6,
            row=0,
            sticky="EW"
        )

        # Entries for name etc.

        self.label_name = Label(
            self.frame,
            text="Voornaam:"
        )
        self.label_name.grid(
            column=0,
            row=3,
            sticky="W"
        )

        self.name = Entry(
            self.frame,
            text="Voornaam"
        )
        self.name.grid(
            column=1,
            row=3,
            sticky="W"
        )
        self.name.delete(0, END)

        self.label_surname = Label(
            self.frame,
            text="Achternaam:"
        )
        self.label_surname.grid(
            column=0,
            row=4,
            sticky="W"
        )

        self.surname = Entry(
            self.frame,
            text="Achternaam"
        )
        self.surname.grid(
            column=1,
            row=4,
            sticky="W"
        )
        self.surname.delete(0, END)

        self.label_card = Label(
            self.frame,
            text="Pasje:"
        )
        self.label_card.grid(
            column=0,
            row=5,
            sticky="W"
        )

        self.card = Label(
            self.frame,
            text=""
        )

        self.card.grid(
            column=1,
            row=5,
            sticky="W"
        )

        self.scanButton = Button(self.frame, text="scan pas", command=self.scanPas)

        self.scanButton.grid(
            column=2,
            row=5,
            sticky="W"
        )

        self.label_subscription = Label(
            self.frame,
            text="Abonnement:"
        )
        self.label_subscription.grid(
            column=0,
            row=6,
            sticky="W"
        )

        # Get data from db for subscriptiondropdown
        sql = """ SELECT name FROM subscription """
        self.c.execute(sql)
        self.conn.commit()
        data = self.c.fetchall()

        i = 0
        while i < len(data):
            data[i]= data[i][0]
            i += 1

        self.subscription_option = StringVar(self.frame)
        self.subscription_option.set("Selecteer uw abonnement")

        self.subscription = OptionMenu(self.frame, self.subscription_option, *data)

        self.subscription.grid(
            column=1,
            row=6,
            sticky="W"
        )

        self.add_user = Button(
            self.frame,
            text="Voeg gebruiker toe",
            command=self.add_user_function
        )
        self.add_user.grid(
            column=1,
            row=7,
            sticky="W"
        )

        self.frame.update()
        self.frame.place(x=(self.winfo_screenwidth() - self.frame.winfo_width())//2, y=0)

    def initialize_add_subscription(self):
        self.clear_grid()

        self.frame = Frame()
        self.frame.grid()

        # ============ Header ================
        self.frame.label_administratie_abonnement = tkinter.Label(
            self.frame,
            text="Toevoegen abonnement",
            font=("Helvetica", 25)
        )
        self.frame.label_administratie_abonnement.grid(
            column=0,
            row=0,
            sticky="W",
            columnspan=4
        )

        self.button_administratie_gebruikers = tkinter.Button(
            self.frame,
            text="Overzicht gebruikers",
            command=self.initialize_administratie_gebruiker
        )
        self.button_administratie_gebruikers.grid(
            column=6,
            row=0,
            sticky="EW"
        )

        # Entries for name etc.

        self.label_subsname = Label(
            self.frame,
            text="Abonnement naam:"
        )
        self.label_subsname.grid(
            column=0,
            row=3,
            sticky="W"
        )

        self.subsname = Entry(
            self.frame,
            text="Abonnement naam"
        )
        self.subsname.grid(
            column=1,
            row=3,
            sticky="W"
        )
        self.subsname.delete(0, END)

        self.label_price = Label(
            self.frame,
            text="Prijs:"
        )
        self.label_price.grid(
            column=0,
            row=4,
            sticky="W"
        )

        self.price = Entry(
            self.frame,
            text="Prijs"
        )
        self.price.grid(
            column=1,
            row=4,
            sticky="W"
        )
        self.price.delete(0, END)

        self.label_duration = Label(
            self.frame,
            text="Tijdsduur:"
        )
        self.label_duration.grid(
            column=0,
            row=5,
            sticky="W"
        )

        self.duration = Entry(
            self.frame,
            text="Tijdsduur"
        )

        self.duration.grid(
            column=1,
            row=5,
            sticky="W"
        )
        self.duration.delete(0, END)


        self.add_subscription = Button(
            self.frame,
            text="Voeg abonnement toe",
            command=self.add_subscription_function
        )
        self.add_subscription.grid(
            column=1,
            row=7,
            sticky="W"
        )

        self.frame.update()
        self.frame.place(x=(self.winfo_screenwidth() - self.frame.winfo_width())//2, y=0)


    def initialize_update_user(self, iduser):
        self.clear_grid()

        self.frame = Frame()
        self.frame.grid()

        # ============ Header ================
        self.label_update_user = tkinter.Label(self.frame, text="Gebruiker aanpassen", font=("Helvetica", 25))
        self.label_update_user.grid(column=0, row=0, sticky="W", columnspan=4)

        self.button_view_users = tkinter.Button(self.frame, text="Overzicht gebruikers",
                                                command=self.initialize_administratie_gebruiker)
        self.button_view_users.grid(column=5, row=0, sticky="EW")

        self.button_gebruiker_toevoegen = tkinter.Button(self.frame, text="Gebruiker toevoegen",
                                                         command=self.initialize_add_user)
        self.button_gebruiker_toevoegen.grid(column=6, row=0, sticky="W")

        # Updatepagina
        sql_query = "SELECT * FROM user WHERE iduser = ?"
        self.c.execute(sql_query, (iduser,))
        self.conn.commit()
        userData = self.c.fetchone()
        sql_query = "SELECT * FROM subscription WHERE idsubscription = (SELECT idsubscription FROM usersubscription WHERE iduser = ?)"
        self.c.execute(sql_query, (iduser,))
        self.conn.commit()
        subscription = (self.c.fetchone())

        self.label_name = Label(self.frame, text="Voornaam:")
        self.label_name.grid(column=0, row=3, sticky="W")

        self.name = Entry(self.frame, text="Voornaam")
        self.name.grid(column=1, row=3, sticky="W")
        self.name.delete(0, END)
        self.name.insert(0, userData[1])

        self.label_surname = Label(self.frame, text="Achternaam:")
        self.label_surname.grid(column=0, row=4, sticky="W")

        self.surname = Entry(self.frame, text="Achternaam")
        self.surname.grid(column=1, row=4, sticky="W")
        self.surname.delete(0, END)
        self.surname.insert(0, userData[2])

        self.label_card = Label(self.frame, text="Pasje:")
        self.label_card.grid(column=0, row=5, sticky="W")

        self.card = Label(
            self.frame,
            text=""
        )

        self.card.grid(
            column=1,
            row=5,
            sticky="W"
        )

        self.scanButton = Button(self.frame, text="scan pas", command=self.scanPas)

        self.scanButton.grid(
            column=2,
            row=5,
            sticky="W"
        )

        # Get data from db for subscriptiondropdown
        sql = """ SELECT name FROM subscription """
        self.c.execute(sql)
        self.conn.commit()
        userData = self.c.fetchall()
        self.subscription_option = StringVar(self.frame)
        self.subscription_option.set(subscription[1])

        self.button_edit_user = Button(self.frame, text="Opslaan",
                                       command=lambda: self.edit_user(iduser, subscription), )
        self.button_edit_user.grid(column=1, row=7, sticky="W")

        self.frame.update()
        self.frame.place(x=(self.winfo_screenwidth() - self.frame.winfo_width())//2, y=0)

    def add_user_function(self):
        # self.clear_grid()
        self.name_entry = self.name.get()
        self.surname_entry = self.surname.get()
        self.card_entry = self.card.cget("text")
        self.subscription_entry = self.subscription_option.get()

        filldb.adduser(self.name_entry, self.surname_entry, self.subscription_entry, self.card_entry)
        tkinter.messagebox.showinfo("Gebruiker toevoegen", "De gebruiker " + self.name_entry + " " + self.surname_entry + " is toegevoegd!")
        self.initialize_administratie_gebruiker()

    def add_subscription_function(self):
        self.subsname_entry = self.subsname.get()
        self.price_entry = self.price.get()
        self.duration_entry = self.duration.get()

        filldb.addsubscription(self.subsname_entry, self.price_entry, self.duration_entry)
        tkinter.messagebox.showinfo("Abonnement toevoegen", "Het abonnement " + self.subsname_entry + " is toegevoegd!")
        self.initialize_administratie_gebruiker()

    def edit_user(self, iduser, subscriptionID):
        self.name_entry = self.name.get()
        self.surname_entry = self.surname.get()
        self.card_entry = self.card.cget("text")
        self.subscription_entry = self.subscription_option.get()
        sql_query = "UPDATE user SET name = ?, surname = ?, idtag = ? WHERE iduser = ?"
        self.c.execute(sql_query, (self.name_entry, self.surname_entry, self.card_entry, iduser,))
        self.conn.commit()
        sql_query = "UPDATE usersubscription SET idsubscription = ? WHERE iduser = ?"
        self.c.execute(sql_query, (subscriptionID[0], iduser))
        self.conn.commit()
        tkinter.messagebox.showinfo("Gebruiker aanpassen", "De gebruiker " + self.name_entry + " " + self.surname_entry + " is aangepast!")
        self.initialize_administratie_gebruiker()

    def deleteuser(self, iduser):
        if (self.confirm_delete_user() == True):

            self.c.execute("DELETE FROM user WHERE iduser = ?", (iduser,))
            self.c.execute("DELETE FROM usersubscription WHERE iduser = ?", (iduser,))
            self.conn.commit()
            self.clear_grid()
            self.initialize_administratie_gebruiker()

    def confirm_delete_user(self):
        var = tkinter.messagebox.askokcancel(
            title="Delete gebruiker",
            message="Wilt u de gebruiker echt verwijderen?"
        )
        return var

    def clear_grid(self):
        if self.frame.winfo_exists() == 1:
            self.frame.destroy()
        if self.headerFrame.winfo_exists() == 1:
            self.headerFrame.destroy()
        if self.mainFrame.winfo_exists() == 1:
            self.mainFrame.destroy()


# Run the application
if __name__ == "__main__":
    app = App(None)
    app.title('Administration')
    app.overrideredirect(True)
    screenWidth = app.winfo_screenwidth()
    screenHeight = app.winfo_screenheight()
    app.geometry("{0}x{1}+0+0".format(screenWidth, screenHeight))
    app.mainloop()
