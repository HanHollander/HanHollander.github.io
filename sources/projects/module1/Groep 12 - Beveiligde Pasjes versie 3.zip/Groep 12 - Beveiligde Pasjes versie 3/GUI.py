__author__ = 'Jeroen'

from tkinter import *
import time


class Window:
    def __init__(self, master, w, h):
        self.master = master
        self.w = w
        self.h = h
        self.status = "Creating database..."
        self.frame = ScanFrame(self, master, w, h, self.status)

    def getMaster(self):
        return self.master

    def getFrame(self):
        return self.frame

    def updateStatus(self, string):
        self.status = string
        self.frame.getLabel(0).config(text=string)

class myFrame(Frame):
    def __init__(self, window, master, w, h, status):
        Frame.__init__(self, master)

        self.master = master
        self.window = window
        self.w = w
        self.h = h

        self.pack(fill=BOTH, expand=1)

        quitButton = Button(self, text="Afsluiten", command=self.quit)
        quitButton.place(x=25, y=25)

        label0 = Label(self, text=status)
        label0.place(x=self.w - label0.winfo_reqwidth() - 20, y=25)
        self.label0 = label0

        label1 = Label(self)
        self.label1 = label1

    def getLabel(self, i):
        if i == 0:
            return self.label0
        elif i == 1:
            return self.label1

class ScanFrame(myFrame):
    def __init__(self, window, master, w, h, status):
        myFrame.__init__(self, window, master, w, h, status)

        self.scanUwPas = PhotoImage(file="assets_werkend/scanUwPas.png")
        self.allow = PhotoImage(file="assets_werkend/allow.png")
        self.denied = PhotoImage(file="assets_werkend/denied.png")
        self.totziens = PhotoImage(file="assets_werkend/totziens.png")
        self.label1.config(image=self.scanUwPas)
        self.label1.photo = self.scanUwPas
        self.label1.place(y=(self.h - 250)//2, x=(self.w - 1000)//2)

    def updateS(self, id, status):
        self.updateScreen(status)
        time.sleep(1.5)
        self.updateScreen(2)

    def updateScreen(self, status):
        # if status == True:
        #     self.label1.config(image=self.allow)
        #     self.label1.photo = self.allow
        if status == 1:
             self.label1.config(image=self.denied)
             self.label1.photo = self.denied
        elif status == 2:
            self.label1.config(image=self.scanUwPas)
            self.label1.photo = self.scanUwPas
        elif status == 3:
            self.label1.config(image=self.totziens)
            self.label1.photo = self.totziens
        elif status == 4:
            self.label1.config(image=self.allow)
            self.label1.photo = self.allow

def setup():
    root = Tk()
    root.configure(background='white')
    root.overrideredirect(True)
    screenWidth = root.winfo_screenwidth()
    screenHeight = root.winfo_screenheight()

    root.geometry("{0}x{1}+0+0".format(screenWidth, screenHeight))
    screen = Window(root, screenWidth, screenHeight)
    return screen
